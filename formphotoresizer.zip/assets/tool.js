/**
 * FormPhotoResize.in — Shared Tool Engine v3
 * assets/tool.js
 *
 * Fixes in v2:
 *  - Binary-search smart KB compression (hits target KB automatically)
 *  - Correct auto-filename per preset (mpscphoto.jpg = 9 chars)
 *  - KB target input wired up
 *  - Validation strip shows pass/fail against maxKB
 *  - Share buttons (WhatsApp + copy link)
 *  - Star rating widget
 *  - No conflicts with any inline script
 *
 * Fixes in v3 (Phase 1):
 *  - Hard max/min dimension clamp (10–3000px) enforced in JS, not just HTML attr
 *  - Download step in the step-bar now turns green ("done") after the file
 *    actually downloads, not just when the result is ready
 *  - Output format locked to JPEG (PNG removed — government portals require JPG)
 *
 * Each page defines window.TOOL_CONFIG before this script loads:
 *   window.TOOL_CONFIG = {
 *     presets: [{ id, icon, name, sizeLabel, kbLabel, w, h, maxKB, format, filename }],
 *     defaultPresetId: 'aadhar',
 *     examName: 'MPSC',
 *   }
 */

(function () {
  'use strict';

  /* ── Limits ── */
  const MAX_DIM = 3000; /* hard cap on width/height in px, matches HTML max attr */
  const MIN_DIM = 10;

  /* ── State ── */
  let originalFile   = null;
  let outputDataURL  = null;
  let outputFilename = 'photo.jpg';
  let activePreset   = null;
  let btnProcessOrigHTML = 'Resize & Compress Photo';
  let brightnessVal  = 100;
  let contrastVal    = 100;

  /* ── DOM refs ── */
  let elPresets, elUploadZone, elFileInput, elBtnProcess, elResultCard,
      elBtnDownload, elInpW, elInpH, elInpFmt, elInpQ, elQDisplay,
      elInpKb, elOrigPreview, elOutPreview, elOrigLabel, elOutLabel,
      elStatOrig, elStatNew, elStatSaved, elStatDim,
      elFilename, elValidation, elStep1, elStep2, elStep3;

  /* ── Init ── */
  function init() {
    elPresets     = document.getElementById('preset-grid');
    elUploadZone  = document.getElementById('upload-zone');
    elFileInput   = document.getElementById('file-input');
    elBtnProcess  = document.getElementById('btn-process');
    if (elBtnProcess) btnProcessOrigHTML = elBtnProcess.innerHTML;
    elResultCard  = document.getElementById('result-card');
    elBtnDownload = document.getElementById('btn-download');
    elInpW        = document.getElementById('inp-w');
    elInpH        = document.getElementById('inp-h');
    elInpFmt      = document.getElementById('inp-fmt');
    elInpQ        = document.getElementById('inp-q');
    elQDisplay    = document.getElementById('q-display');
    elInpKb       = document.getElementById('inp-kb');
    elOrigPreview = document.getElementById('orig-preview');
    elOutPreview  = document.getElementById('out-preview');
    elOrigLabel   = document.getElementById('orig-label');
    elOutLabel    = document.getElementById('out-label');
    elStatOrig    = document.getElementById('stat-orig');
    elStatNew     = document.getElementById('stat-new');
    elStatSaved   = document.getElementById('stat-saved');
    elStatDim     = document.getElementById('stat-dim');
    elFilename    = document.getElementById('dl-filename');
    elValidation  = document.getElementById('validation-strip');
    elStep1       = document.getElementById('step-1');
    elStep2       = document.getElementById('step-2');
    elStep3       = document.getElementById('step-3');

    /* ── Hide quality slider + target KB (auto-handled via binary search) ── */
    const qualityWrap = document.querySelector('.quality-wrap');
    const kbRow       = document.querySelector('.target-kb-row');
    const settingsGrid = document.querySelector('.settings-grid');
    if (qualityWrap) qualityWrap.style.display = 'none';
    if (kbRow)       kbRow.style.display       = 'none';

    /* ── Inject Brightness + Contrast sliders ── */
    if (settingsGrid && !document.getElementById('adj-brightness')) {
      const adjWrap = document.createElement('div');
      adjWrap.className = 'adj-sliders';
      adjWrap.innerHTML = `
        <div class="adj-row">
          <label class="adj-label">
            <span>☀️ Brightness</span>
            <span class="adj-val" id="adj-b-val">0</span>
          </label>
          <input type="range" id="adj-brightness" min="-50" max="50" value="0" step="1">
        </div>
        <div class="adj-row">
          <label class="adj-label">
            <span>◑ Contrast</span>
            <span class="adj-val" id="adj-c-val">0</span>
          </label>
          <input type="range" id="adj-contrast" min="-50" max="50" value="0" step="1">
        </div>
        <button class="adj-reset" id="adj-reset">↺ Reset adjustments</button>`;
      settingsGrid.insertAdjacentElement('afterend', adjWrap);

      const bSlider = document.getElementById('adj-brightness');
      const cSlider = document.getElementById('adj-contrast');
      const bVal    = document.getElementById('adj-b-val');
      const cVal    = document.getElementById('adj-c-val');
      const resetBtn = document.getElementById('adj-reset');

      bSlider.addEventListener('input', () => {
        brightnessVal = 100 + parseInt(bSlider.value) * 1.5;
        bVal.textContent = (bSlider.value > 0 ? '+' : '') + bSlider.value;
        _applyLiveFilter();
      });
      cSlider.addEventListener('input', () => {
        contrastVal = 100 + parseInt(cSlider.value) * 2;
        cVal.textContent = (cSlider.value > 0 ? '+' : '') + cSlider.value;
        _applyLiveFilter();
      });
      resetBtn.addEventListener('click', () => {
        brightnessVal = 100; contrastVal = 100;
        bSlider.value = 0; cSlider.value = 0;
        bVal.textContent = '0'; cVal.textContent = '0';
        _applyLiveFilter();
      });
    }

    const config = window.TOOL_CONFIG || {};

    /* ── Render preset buttons ── */
    if (elPresets && config.presets && config.presets.length) {
      elPresets.innerHTML = '';
      config.presets.forEach((p, i) => {
        const btn = document.createElement('button');
        btn.className   = 'preset-btn' + (i === 0 ? ' active' : '');
        btn.dataset.id  = p.id;
        btn.innerHTML   = `
          <span class="p-icon">${p.icon || '📄'}</span>
          <span class="p-name">${p.name}</span>
          <span class="p-size">${p.sizeLabel}</span>
          <span class="p-kb">${p.kbLabel}</span>`;
        btn.addEventListener('click', () => selectPreset(p, btn));
        elPresets.appendChild(btn);
      });
      selectPreset(config.presets[0], elPresets.querySelector('.preset-btn'));
    }

    /* ── Quality slider ── */
    if (elInpQ && elQDisplay) {
      elInpQ.addEventListener('input', () => { elQDisplay.textContent = elInpQ.value + '%'; });
    }

    /* ── Clamp width/height to MIN_DIM–MAX_DIM (blur = once user finishes typing) ── */
    [elInpW, elInpH].forEach(inp => {
      if (!inp) return;
      inp.addEventListener('blur', () => { inp.value = clampDim(inp.value); });
    });

    /* ── Upload zone ── */
    if (elUploadZone) {
      /* Inject AI auto-face-crop toggle (shared across all resizer pages) */
      if (!document.getElementById('auto-face-toggle')) {
        const wrap = document.createElement('div');
        wrap.className = 'auto-face-wrap';
        wrap.innerHTML = `
          <label class="auto-face-toggle">
            <input type="checkbox" id="auto-face-toggle" checked>
            <span>🎯 Auto-centre face with AI <em>(recommended)</em></span>
          </label>
          <div class="face-status" id="face-status" style="display:none;"></div>`;
        elUploadZone.insertAdjacentElement('afterend', wrap);
      }

      elUploadZone.addEventListener('click', () => elFileInput && elFileInput.click());
      elUploadZone.addEventListener('dragover', e => { e.preventDefault(); elUploadZone.classList.add('drag'); });
      elUploadZone.addEventListener('dragleave', () => elUploadZone.classList.remove('drag'));
      elUploadZone.addEventListener('drop', e => {
        e.preventDefault(); elUploadZone.classList.remove('drag');
        const f = e.dataTransfer.files[0];
        if (f && f.type.startsWith('image/')) loadFile(f);
        else showUploadError('Please drop a JPG or PNG image.');
      });
    }
    if (elFileInput) {
      elFileInput.addEventListener('change', () => {
        if (elFileInput.files[0]) loadFile(elFileInput.files[0]);
      });
    }
    const elAutoFace = document.getElementById('auto-face-toggle');
    if (elAutoFace) {
      elAutoFace.addEventListener('change', () => {
        if (elFileInput && elFileInput.files[0]) loadFile(elFileInput.files[0]);
      });
    }

    /* ── Process & download ── */
    if (elBtnProcess)  elBtnProcess.addEventListener('click', processImage);
    if (elBtnDownload) elBtnDownload.addEventListener('click', downloadImage);

    /* ── Share buttons ── */
    const shareWa = document.getElementById('share-wa');
    const shareCopy = document.getElementById('share-copy');
    if (shareWa) {
      shareWa.addEventListener('click', () => {
        window.open('https://wa.me/?text=' + encodeURIComponent(
          'Free tool to resize photos for government forms (Aadhar, PAN, MPSC, SSC) — ' + location.href
        ));
      });
    }
    if (shareCopy) {
      shareCopy.addEventListener('click', function () {
        navigator.clipboard.writeText(location.href).then(() => {
          this.textContent = 'Copied!';
          setTimeout(() => { this.textContent = 'Copy Link'; }, 2000);
        });
      });
    }

    /* ── Star rating ── */
    const stars = document.querySelectorAll('.star-btn');
    const ratingThanks = document.getElementById('rating-thanks');
    let ratingLocked = false;

    /* Inject star animation keyframes once */
    if (!document.getElementById('star-burst-style')) {
      const ss = document.createElement('style');
      ss.id = 'star-burst-style';
      ss.textContent = `
        .star-btn        { opacity: 0.3; transition: opacity 0.1s, transform 0.15s; }
        .star-btn.lit    { opacity: 1; }
        .star-btn:hover  { transform: scale(1.2); }
        .star-btn.burst  { transform: scale(1.2); }
        #rating-thanks   { transition: opacity 0.3s ease, transform 0.3s ease; }
        #rating-thanks.hidden-pre { opacity: 0; transform: translateY(6px); }
      `;
      document.head.appendChild(ss);
    }

    if (stars.length) {
      /* Pre-hide thanks so first reveal can animate in */
      if (ratingThanks) ratingThanks.classList.add('hidden-pre');

      stars.forEach(star => {
        star.addEventListener('mouseover', () => {
          if (ratingLocked) return;
          const v = +star.dataset.v;
          stars.forEach(s => s.classList.toggle('lit', +s.dataset.v <= v));
        });
        star.addEventListener('mouseout', () => {
          if (ratingLocked) return;
          stars.forEach(s => s.classList.remove('lit'));
        });
        star.addEventListener('click', () => {
          if (ratingLocked) return;
          ratingLocked = true;

          const v = +star.dataset.v;

          /* Light up stars up to the tapped one, burst each with staggered delay */
          stars.forEach(s => {
            const sv = +s.dataset.v;
            const isLit = sv <= v;
            s.classList.toggle('lit', isLit);
            s.style.pointerEvents = 'none';   /* lock all stars */

            if (isLit) {
              /* Stagger: each filled star pops 40ms after the previous */
              const delay = (sv - 1) * 40;
              setTimeout(() => {
                s.classList.remove('burst');
                void s.offsetWidth;            /* force reflow to re-trigger animation */
                s.classList.add('burst');
              }, delay);
            }
          });

          /* Show thanks message with slide-in after the last star bursts */
          const revealDelay = (v - 1) * 40 + 280;
          setTimeout(() => {
            if (ratingThanks) {
              ratingThanks.style.display = 'block';
              /* Tiny rAF so display:block is painted before we remove hidden-pre */
              requestAnimationFrame(() => {
                requestAnimationFrame(() => ratingThanks.classList.remove('hidden-pre'));
              });
              /* Update thanks text to reflect the actual rating given */
              const messages = ['', 'Thanks for the feedback!', 'Thanks for the feedback!',
                                    'Glad it helped! 😊', 'Great, thanks! 😊', 'Awesome, thank you! 🎉'];
              const msg = ratingThanks.querySelector('p') || ratingThanks;
              if (msg) msg.textContent = messages[v] || 'Thank you!';
            }
          }, revealDelay);
        });
      });
    }

    /* ── FAQ accordion ── */
    document.querySelectorAll('.faq-q-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const item    = btn.closest('.faq-item');
        const wasOpen = item.classList.contains('open');
        document.querySelectorAll('.faq-item.open').forEach(i => i.classList.remove('open'));
        if (!wasOpen) item.classList.add('open');
      });
    });

    /* ── Mobile nav toggle ── */
    const navToggle = document.querySelector('.nav-toggle');
    const siteNav   = document.querySelector('.site-nav');
    if (navToggle && siteNav) {
      navToggle.addEventListener('click', () => siteNav.classList.toggle('open'));
    }

    setStep(1);
  }

  /* ── Preset selection ── */
  function selectPreset(preset, btn) {
    activePreset = preset;
    document.querySelectorAll('.preset-btn').forEach(b => b.classList.remove('active'));
    if (btn) btn.classList.add('active');
    if (elInpW)   elInpW.value   = preset.w      || 200;
    if (elInpH)   elInpH.value   = preset.h      || 200;
    if (elInpFmt) elInpFmt.value = preset.format  || 'jpeg';
    if (elInpKb && preset.maxKB) elInpKb.value = preset.maxKB;

    /* Hide AI face-crop toggle for signature presets — not relevant */
    const faceWrap = document.querySelector('.auto-face-wrap');
    // if (faceWrap) {
    //   const isSignature = preset.id && preset.id.toLowerCase().includes('sign');
    //   faceWrap.style.display = isSignature ? 'none' : '';

    //   const isThumb = preset.id && preset.id.toLowerCase().includes('thumb');
    //   faceWrap.style.display = isThumb ? 'none' : '';

    //   /* Also uncheck + disable so it doesn't run on signature uploads */
    //   const toggle = document.getElementById('auto-face-toggle');
    //   if (toggle) {
    //     toggle.checked  = !isSignature;
    //     toggle.disabled =  isSignature;
    //   }
    // }
    if (faceWrap) {
      const presetId = (preset.id || '').toLowerCase();
    
      const isSignature = presetId.includes('sign');
      const isThumb = presetId.includes('thumb');
    
      const hideFaceCrop = isSignature || isThumb;
    
      faceWrap.style.display = hideFaceCrop ? 'none' : '';
    
      const toggle = document.getElementById('auto-face-toggle');
      if (toggle) {
        toggle.checked = !hideFaceCrop;
        toggle.disabled = hideFaceCrop;
      }
    }
  }

  /* ── Load file ── */
  function loadFile(file) {
    if (elBtnProcess) elBtnProcess.disabled = false;

    const reader = new FileReader();
    reader.onload = e => {
      const dataURL = e.target.result;

      if (isAutoFaceEnabled()) {
        /* Show the uploaded photo immediately, with a clearly visible
           scanning overlay on top of it — so the user sees right away
           that the upload worked and that something is happening,
           instead of staring at the empty drop-zone wondering why
           their photo isn't showing. */
        renderLivePreview(dataURL, file);
        setFaceScanOverlay(true, '🔎 Detecting face…');

        const img = new Image();
        img.onload = () => tryFaceCrop(img, file, dataURL);
        img.src = dataURL;
      } else {
        finishLoad(file, dataURL);
      }
    };
    reader.readAsDataURL(file);
  }

  /* ── AI face auto-crop ── */
  function isAutoFaceEnabled() {
    const t = document.getElementById('auto-face-toggle');
    return !!(t && t.checked);
  }

  function setFaceStatus(msg, kind) {
    const el = document.getElementById('face-status');
    if (!el) return;
    el.textContent = msg || '';
    el.className = 'face-status' + (kind ? ' ' + kind : '');
    el.style.display = msg ? 'flex' : 'none';
  }

  /* ── Prominent scanning overlay shown on top of the live preview while
     face detection is running (separate from the small text strip below
     the toggle, which is easy to miss) ── */
  function setFaceScanOverlay(show, label) {
    if (!elUploadZone) return;
    let overlay = elUploadZone.querySelector('.face-scan-overlay');
    if (!overlay) {
      overlay = document.createElement('div');
      overlay.className = 'face-scan-overlay';
      overlay.innerHTML = `
        <div class="face-scan-line"></div>
        <div class="face-scan-label" id="face-scan-label"></div>
        <div class="face-scan-bar-track"><div class="face-scan-bar-fill"></div></div>`;
      elUploadZone.appendChild(overlay);
    }
    const labelEl = overlay.querySelector('#face-scan-label');
    if (labelEl) labelEl.textContent = label || 'Detecting face…';
    overlay.classList.toggle('show', !!show);
  }

  function tryFaceCrop(img, file, dataURL) {
    setFaceStatus('🔎 Detecting face… (first time may take a few seconds)', 'busy');
    setFaceScanOverlay(true, '🔎 Detecting face…');
    const toolScript = document.querySelector('script[src*="tool.js"]');
    const modUrl = toolScript ? new URL('ai-facecrop.js', toolScript.src) : './ai-facecrop.js';
    import(modUrl)
      .then(mod => mod.autoFaceCrop(img))
      .then(canvas => {
        if (!canvas) {
          setFaceStatus('ℹ️ No face detected — using full photo', 'info');
          finishLoad(file, dataURL);
          return;
        }
        const mime = file.type === 'image/png' ? 'image/png' : 'image/jpeg';
        canvas.toBlob(blob => {
          if (!blob) { finishLoad(file, dataURL); return; }
          const cropped = new File([blob], file.name, { type: mime });
          setFaceStatus('✅ Face detected & auto-centred', 'ok');
          finishLoad(cropped, canvas.toDataURL(mime));
        }, mime, 0.95);
      })
      .catch(err => {
        console.warn('[ai-facecrop] failed:', err);
        setFaceStatus('ℹ️ Face detection unavailable — using full photo', 'info');
        finishLoad(file, dataURL);
      });
  }

  /* ── Render (or update) the live photo preview inside the upload zone.
     Shared by the immediate "just uploaded" preview and the final
     post-face-crop preview, so the photo never disappears in between. ── */
  function renderLivePreview(dataURL, file) {
    if (!elUploadZone) return;
    elUploadZone.classList.add('loaded');

    let previewImg = elUploadZone.querySelector('.upload-live-preview');
    if (!previewImg) {
      previewImg = document.createElement('img');
      previewImg.className = 'upload-live-preview';
      previewImg.alt = 'Uploaded photo preview';
      elUploadZone.insertBefore(previewImg, elUploadZone.firstChild);
    }
    previewImg.src = dataURL;

    /* Update text elements */
    const icon  = elUploadZone.querySelector('.upload-icon');
    const title = elUploadZone.querySelector('.upload-title');
    const sub   = elUploadZone.querySelector('.upload-sub');
    const hint  = elUploadZone.querySelector('.upload-hint');
    if (icon)  icon.style.display  = 'none';
    if (title) title.style.display = 'none';
    if (hint)  hint.style.display  = 'none';
    if (sub) {
      const kb = fmtKB(file.size);
      sub.innerHTML = `<span class="upload-change-hint">📁 <strong>${file.name}</strong> · ${kb} · Click to change</span>`;
    }
  }

  function finishLoad(file, dataURL) {
    originalFile = file;
    if (elOrigPreview) elOrigPreview.src = dataURL;
    const kb = fmtKB(file.size);
    if (elOrigLabel) elOrigLabel.innerHTML = `Original &nbsp;<span class=\"size-tag\">${kb}</span>`;
    if (elStatOrig)  elStatOrig.textContent = kb;

    renderLivePreview(dataURL, file);
    setFaceScanOverlay(false);

    if (elResultCard) elResultCard.classList.remove('show');
    setStep(2);
  }

  /* ── Live filter preview on upload zone photo ── */
  function _applyLiveFilter() {
    const previewImg = elUploadZone && elUploadZone.querySelector('.upload-live-preview');
    if (previewImg) {
      previewImg.style.filter = `brightness(${brightnessVal}%) contrast(${contrastVal}%)`;
    }
  }

  /* ── Show upload error ── */
  function showUploadError(msg) {
    if (!elUploadZone) return;
    const sub = elUploadZone.querySelector('.upload-sub');
    if (sub) {
      sub.style.color = '#DC2626'; sub.textContent = msg;
      setTimeout(() => { sub.style.color = ''; sub.innerHTML = 'JPG, PNG supported · Max 10 MB'; }, 3000);
    }
  }

  /* ── Binary-search KB compression ── v5
   *
   * Three rules:
   *
   * RULE 1 — Already under limit → dimension-resize only, zero compression.
   *   If the canvas at near-lossless quality (0.97) is already <= targetKB,
   *   return it as-is. The user asked for a size limit, not forced compression.
   *   e.g. 35 KB original -> 50 KB limit -> just resize dimensions, keep quality.
   *
   * RULE 2 — Needs compression -> aim for 90-95% of limit, NOT under it.
   *   Binary-search upward from the buffered floor so the result lands as
   *   close to the limit as possible (18-19 KB for 20 KB, 45-48 KB for 50 KB,
   *   90-95 KB for 100 KB). Never compress more than necessary.
   *
   * RULE 3 — Truly oversized even at lowest quality -> best effort.
   */
  function compressToTargetKB(canvas, mime, targetKB) {
    if (mime === 'image/png') return canvas.toDataURL('image/png');

    const hardLimitBytes = targetKB * 1024;
    const floorBytes     = Math.max(1, targetKB * 0.90) * 1024; // aim for >=90% of limit

    /* RULE 1: Near-lossless encode fits under hard limit -> ship it, no compression */
    const NEAR_LOSSLESS = 0.97;
    const nlURL   = canvas.toDataURL(mime, NEAR_LOSSLESS);
    const nlBytes = b64Bytes(nlURL);
    if (nlBytes <= hardLimitBytes) {
      console.info(`[compress] Already under ${targetKB} KB at q=0.97 (${(nlBytes/1024).toFixed(1)} KB) — skipping compression.`);
      return nlURL;
    }

    /* RULE 2: Must compress — binary-search to land between 90-100% of limit.
       Find highest quality whose output is <= hardLimitBytes, prefer closest to floorBytes. */
    let lo = 0.05, hi = NEAR_LOSSLESS;
    let bestURL   = null;
    let bestBytes = 0;

    for (let i = 0; i < 16; i++) {
      const mid   = (lo + hi) / 2;
      const url   = canvas.toDataURL(mime, mid);
      const bytes = b64Bytes(url);

      if (bytes <= hardLimitBytes) {
        if (bytes > bestBytes) { bestURL = url; bestBytes = bytes; }
        lo = mid;
      } else {
        hi = mid;
      }

      if (hi - lo < 0.004) break;
    }

    /* RULE 3: Nothing fit — return the smallest we found */
    if (!bestURL) bestURL = canvas.toDataURL(mime, lo);

    console.info(`[compress] Compressed to ${(b64Bytes(bestURL)/1024).toFixed(1)} KB (limit: ${targetKB} KB)`);
    return bestURL;
  }

  /* ── Process image ── */
  function processImage() {
    if (!originalFile) return;

    const w   = clampDim(elInpW ? elInpW.value : 200);
    const h   = clampDim(elInpH ? elInpH.value : 200);
    if (elInpW) elInpW.value = w;
    if (elInpH) elInpH.value = h;
    const fmt = elInpFmt ? elInpFmt.value : 'jpeg';
    const manualQ = elInpQ ? parseInt(elInpQ.value) / 100 : 0.82;

    /* Target KB: use inp-kb if present, else fallback to preset maxKB, else manual quality */
    const targetKB = elInpKb && elInpKb.value
      ? parseInt(elInpKb.value)
      : (activePreset && activePreset.maxKB ? activePreset.maxKB : null);

    if (elBtnProcess) {
      elBtnProcess.disabled = true;
      elBtnProcess.innerHTML = '<span style="display:inline-flex;align-items:center;gap:8px"><svg style="animation:spin .7s linear infinite" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18"><path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83"/></svg>Processing…</span>';
    }

    const reader = new FileReader();
    reader.onload = e => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = w; canvas.height = h;
        const ctx = canvas.getContext('2d');

        /* White background */
        ctx.fillStyle = '#FFFFFF';
        ctx.fillRect(0, 0, w, h);

        /* Apply brightness/contrast adjustments */
        if (brightnessVal !== 100 || contrastVal !== 100) {
          ctx.filter = `brightness(${brightnessVal}%) contrast(${contrastVal}%)`;
        }

        /* Cover-crop — face-aware centre */
        const srcAsp = img.width / img.height;
        const dstAsp = w / h;
        let sx, sy, sw, sh;
        if (srcAsp > dstAsp) {
          /* Source wider than target — trim sides equally */
          sh = img.height; sw = sh * dstAsp;
          sx = (img.width - sw) / 2; sy = 0;
        } else {
          /* Source taller than target (portrait→square) — trim from bottom,
             keeping the top where the face sits after ai-facecrop.
             Starts 25% down instead of 50% so the head is never clipped. */
          sw = img.width; sh = sw / dstAsp;
          sx = 0;
          const maxSy = img.height - sh;
          sy = Math.min(maxSy * 0.25, maxSy);
        }
        ctx.drawImage(img, sx, sy, sw, sh, 0, 0, w, h);

        const mime = fmt === 'png' ? 'image/png' : 'image/jpeg';

        /* Smart compression: use binary search if targetKB set, else manual quality */
        if (targetKB && fmt !== 'png') {
          outputDataURL = compressToTargetKB(canvas, mime, targetKB);
        } else {
          outputDataURL = canvas.toDataURL(mime, manualQ);
        }

        const outBytes  = b64Bytes(outputDataURL);
        const origBytes = originalFile.size;
        const savedBytes = origBytes - outBytes;
        const savedPct   = savedBytes > 0 ? Math.round((savedBytes / origBytes) * 100) : 0;

        /* Populate result UI */
        if (elOutPreview) elOutPreview.src = outputDataURL;
        if (elOutLabel)   elOutLabel.innerHTML  = `Resized &nbsp;<span class="size-tag">${fmtKB(outBytes)}</span>`;
        if (elStatNew)    elStatNew.textContent  = fmtKB(outBytes);
        if (elStatSaved) {
          elStatSaved.textContent = savedBytes > 0
            ? `−${fmtKB(savedBytes)} (${savedPct}%)`
            : '+' + fmtKB(Math.abs(savedBytes));
          const box = elStatSaved.closest('.stat-box');
          if (box) box.className = 'stat-box ' + (savedBytes > 0 ? 'success' : 'warn');
        }
        if (elStatDim) elStatDim.textContent = `${w} × ${h} px`;

        /* Auto filename — preset filename takes priority */
        const ext = fmt === 'png' ? 'png' : 'jpg';
        if (activePreset && activePreset.filename) {
          outputFilename = activePreset.filename + '.' + ext;
        } else {
          const slug = activePreset
            ? activePreset.id
            : (window.TOOL_CONFIG && window.TOOL_CONFIG.examName
                ? window.TOOL_CONFIG.examName.toLowerCase().replace(/\s+/g, '')
                : 'photo');
          outputFilename = slug + 'photo.' + ext;
        }
        if (elFilename) elFilename.textContent = outputFilename;

        /* Validation strip — KB check */
        if (elValidation) {
          const outKB = outBytes / 1024;
          const limit = targetKB || (activePreset && activePreset.maxKB);
          if (limit) {
            if (outKB <= limit) {
              elValidation.className = 'validation-strip pass';
              elValidation.innerHTML = `✅ &nbsp;${fmtKB(outBytes)} — within the ${limit} KB limit`;
            } else {
              elValidation.className = 'validation-strip fail';
              elValidation.innerHTML = `⚠️ &nbsp;${fmtKB(outBytes)} — over the ${limit} KB limit. Lower quality slider further.`;
            }
            elValidation.style.display = 'flex';
          }
        }

        if (elResultCard) {
          elResultCard.classList.add('show');
          elResultCard.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }

        /* Show rating box if present */
        const ratingBox = document.getElementById('rating-box');
        if (ratingBox) ratingBox.style.display = 'block';

        setStep(3);

        if (elBtnProcess) {
          elBtnProcess.disabled = false;
          elBtnProcess.innerHTML = 'Resize & Compress Photo';
        }
      };
      img.src = e.target.result;
    };
    reader.readAsDataURL(originalFile);
  }

  /* ── Download ── */
  function downloadImage() {
    if (!outputDataURL) return;
    const a = document.createElement('a');
    a.href = outputDataURL;
    a.download = outputFilename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);

    /* Mark step 3 (Download) as done/green now that the file has actually been saved */
    if (elStep3) {
      elStep3.classList.remove('active');
      elStep3.classList.add('done');
    }
    if (elBtnDownload) {
      const origHTML = elBtnDownload.dataset.origHtml || elBtnDownload.innerHTML;
      elBtnDownload.dataset.origHtml = origHTML;
      elBtnDownload.classList.add('downloaded');
      elBtnDownload.innerHTML = '✅ Downloaded';
      clearTimeout(elBtnDownload._resetTimer);
      elBtnDownload._resetTimer = setTimeout(() => {
        elBtnDownload.classList.remove('downloaded');
        elBtnDownload.innerHTML = origHTML;
      }, 2500);
    }
  }

  /* ── Step bar ── */
  function setStep(n) {
    [elStep1, elStep2, elStep3].forEach((el, i) => {
      if (!el) return;
      el.classList.remove('active', 'done');
      if (i + 1 < n)  el.classList.add('done');
      if (i + 1 === n) el.classList.add('active');
    });
  }

  /* ── Helpers ── */
  function clampDim(val) {
    let n = parseInt(val, 10);
    if (isNaN(n)) n = 200;
    if (n < MIN_DIM) n = MIN_DIM;
    if (n > MAX_DIM) n = MAX_DIM;
    return n;
  }

  function b64Bytes(dataURL) {
    try { return Math.round(atob(dataURL.split(',')[1]).length); }
    catch { return 0; }
  }

  function fmtKB(bytes) {
    if (bytes < 1024) return bytes + ' B';
    return (bytes / 1024).toFixed(1) + ' KB';
  }

  /* ── Spin animation ── */
  const sty = document.createElement('style');
  sty.textContent = '@keyframes spin{to{transform:rotate(360deg)}}';
  document.head.appendChild(sty);

  /* ── Boot ── */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  window.FPR = { selectPreset, loadFile, processImage, downloadImage };

})();
